package com.videodownloader.app.utils

import android.util.Log
import com.videodownloader.app.model.Platform
import com.videodownloader.app.model.VideoFormat
import com.videodownloader.app.model.VideoInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLDecoder
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

class VideoExtractor {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true)
        .addInterceptor { chain ->
            val request = chain.request().newBuilder()
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36")
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8")
                .header("Accept-Language", "ar,en;q=0.9")
                .build()
            chain.proceed(request)
        }
        .build()

    suspend fun extractVideoInfo(url: String): Result<VideoInfo> = withContext(Dispatchers.IO) {
        try {
            val cleanUrl = cleanUrl(url)
            val platform = Platform.fromUrl(cleanUrl)

            when (platform) {
                Platform.YOUTUBE -> extractYoutube(cleanUrl)
                Platform.TIKTOK -> extractTikTok(cleanUrl)
                Platform.INSTAGRAM -> extractInstagram(cleanUrl)
                Platform.TWITTER -> extractTwitter(cleanUrl)
                Platform.FACEBOOK -> extractFacebook(cleanUrl)
                else -> extractGeneric(cleanUrl, platform)
            }
        } catch (e: Exception) {
            Log.e("VideoExtractor", "Error extracting video", e)
            Result.failure(e)
        }
    }

    private fun cleanUrl(url: String): String {
        return url.trim().let {
            // Remove tracking parameters for cleaner URLs
            if (it.contains("?") && (it.contains("youtube.com/watch") || it.contains("youtu.be"))) {
                val baseUrl = it.substringBefore("?")
                val params = it.substringAfter("?")
                val videoId = params.split("&").find { p -> p.startsWith("v=") }
                if (videoId != null) "$baseUrl?$videoId" else it
            } else it
        }
    }

    // ─── YouTube ───────────────────────────────────────────────────────────────
    private suspend fun extractYoutube(url: String): Result<VideoInfo> = withContext(Dispatchers.IO) {
        try {
            val videoId = extractYoutubeId(url)
                ?: return@withContext Result.failure(Exception("لا يمكن استخراج معرف الفيديو"))

            // Use YouTube oEmbed for title and thumbnail
            val oembedUrl = "https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=$videoId&format=json"
            val request = Request.Builder().url(oembedUrl).build()
            val response = client.newCall(request).execute()

            var title = "فيديو YouTube"
            var thumbnail = "https://img.youtube.com/vi/$videoId/maxresdefault.jpg"

            if (response.isSuccessful) {
                val json = JSONObject(response.body?.string() ?: "{}")
                title = json.optString("title", "فيديو YouTube")
                thumbnail = json.optString("thumbnail_url", thumbnail)
            }

            // Use a YouTube download API (cobalt.tools compatible)
            val formats = listOf(
                VideoFormat("4K Ultra HD", "2160", "https://cobalt.tools/api/?url=${url}&vCodec=av1&vQuality=2160", "mp4", "~2.5 GB"),
                VideoFormat("1080p Full HD", "1080", "https://cobalt.tools/api/?url=${url}&vCodec=h264&vQuality=1080", "mp4", "~500 MB"),
                VideoFormat("720p HD", "720", "https://cobalt.tools/api/?url=${url}&vCodec=h264&vQuality=720", "mp4", "~200 MB"),
                VideoFormat("480p", "480", "https://cobalt.tools/api/?url=${url}&vCodec=h264&vQuality=480", "mp4", "~100 MB"),
                VideoFormat("360p", "360", "https://cobalt.tools/api/?url=${url}&vCodec=h264&vQuality=360", "mp4", "~50 MB"),
                VideoFormat("صوت فقط MP3", "audio", "https://cobalt.tools/api/?url=${url}&isAudioOnly=true", "mp3", "~5 MB", isAudioOnly = true)
            )

            Result.success(
                VideoInfo(
                    title = title,
                    url = url,
                    thumbnailUrl = thumbnail,
                    platform = Platform.YOUTUBE,
                    formats = formats
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun extractYoutubeId(url: String): String? {
        val patterns = listOf(
            "(?:youtube\\.com/watch\\?.*v=|youtu\\.be/)([a-zA-Z0-9_-]{11})",
            "youtube\\.com/embed/([a-zA-Z0-9_-]{11})",
            "youtube\\.com/shorts/([a-zA-Z0-9_-]{11})"
        )
        for (pattern in patterns) {
            val matcher = Pattern.compile(pattern).matcher(url)
            if (matcher.find()) return matcher.group(1)
        }
        return null
    }

    // ─── TikTok ────────────────────────────────────────────────────────────────
    private suspend fun extractTikTok(url: String): Result<VideoInfo> = withContext(Dispatchers.IO) {
        try {
            // Use TikWM API (public, no auth needed)
            val apiUrl = "https://www.tikwm.com/api/?url=${url}&hd=1"
            val request = Request.Builder().url(apiUrl).build()
            val response = client.newCall(request).execute()

            if (response.isSuccessful) {
                val body = response.body?.string() ?: ""
                val json = JSONObject(body)
                val data = json.optJSONObject("data")

                if (data != null) {
                    val title = data.optString("title", "فيديو TikTok")
                    val cover = data.optString("cover", "")
                    val hdVideo = data.optString("hdplay", "")
                    val sdVideo = data.optString("play", "")
                    val music = data.optString("music", "")
                    val duration = data.optInt("duration", 0)

                    val formats = mutableListOf<VideoFormat>()
                    if (hdVideo.isNotEmpty()) {
                        formats.add(VideoFormat("HD - بدون علامة مائية", "hd", hdVideo, "mp4", null))
                    }
                    if (sdVideo.isNotEmpty()) {
                        formats.add(VideoFormat("SD - بدون علامة مائية", "sd", sdVideo, "mp4", null))
                    }
                    if (music.isNotEmpty()) {
                        formats.add(VideoFormat("صوت فقط MP3", "audio", music, "mp3", null, isAudioOnly = true))
                    }

                    return@withContext Result.success(
                        VideoInfo(
                            title = title,
                            url = url,
                            thumbnailUrl = cover.ifEmpty { null },
                            duration = if (duration > 0) formatDuration(duration) else null,
                            platform = Platform.TIKTOK,
                            formats = formats
                        )
                    )
                }
            }

            // Fallback
            Result.success(
                VideoInfo(
                    title = "فيديو TikTok",
                    url = url,
                    platform = Platform.TIKTOK,
                    formats = listOf(
                        VideoFormat("HD - بدون علامة مائية", "hd", url, "mp4"),
                        VideoFormat("صوت فقط", "audio", url, "mp3", isAudioOnly = true)
                    )
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ─── Instagram ─────────────────────────────────────────────────────────────
    private suspend fun extractInstagram(url: String): Result<VideoInfo> = withContext(Dispatchers.IO) {
        try {
            // Use Instagram oEmbed
            val oembedUrl = "https://api.instagram.com/oembed/?url=$url"
            val request = Request.Builder().url(oembedUrl).build()
            val response = client.newCall(request).execute()

            var title = "فيديو Instagram"
            var thumbnail: String? = null

            if (response.isSuccessful) {
                val json = JSONObject(response.body?.string() ?: "{}")
                title = json.optString("title", "فيديو Instagram")
                thumbnail = json.optString("thumbnail_url", "").ifEmpty { null }
            }

            Result.success(
                VideoInfo(
                    title = title,
                    url = url,
                    thumbnailUrl = thumbnail,
                    platform = Platform.INSTAGRAM,
                    formats = listOf(
                        VideoFormat("جودة عالية", "hd", url, "mp4"),
                        VideoFormat("جودة عادية", "sd", url, "mp4")
                    )
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ─── Twitter/X ─────────────────────────────────────────────────────────────
    private suspend fun extractTwitter(url: String): Result<VideoInfo> = withContext(Dispatchers.IO) {
        try {
            Result.success(
                VideoInfo(
                    title = "فيديو Twitter/X",
                    url = url,
                    platform = Platform.TWITTER,
                    formats = listOf(
                        VideoFormat("1080p", "1080", url, "mp4"),
                        VideoFormat("720p", "720", url, "mp4"),
                        VideoFormat("480p", "480", url, "mp4")
                    )
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ─── Facebook ──────────────────────────────────────────────────────────────
    private suspend fun extractFacebook(url: String): Result<VideoInfo> = withContext(Dispatchers.IO) {
        try {
            Result.success(
                VideoInfo(
                    title = "فيديو Facebook",
                    url = url,
                    platform = Platform.FACEBOOK,
                    formats = listOf(
                        VideoFormat("HD", "hd", url, "mp4"),
                        VideoFormat("SD", "sd", url, "mp4")
                    )
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ─── Generic ───────────────────────────────────────────────────────────────
    private suspend fun extractGeneric(url: String, platform: Platform): Result<VideoInfo> =
        withContext(Dispatchers.IO) {
            try {
                Result.success(
                    VideoInfo(
                        title = "فيديو من ${platform.displayName}",
                        url = url,
                        platform = platform,
                        formats = listOf(
                            VideoFormat("جودة عالية", "best", url, "mp4"),
                            VideoFormat("جودة منخفضة", "worst", url, "mp4")
                        )
                    )
                )
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    private fun formatDuration(seconds: Int): String {
        val h = seconds / 3600
        val m = (seconds % 3600) / 60
        val s = seconds % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, s)
        else String.format("%d:%02d", m, s)
    }

    fun isValidUrl(url: String): Boolean {
        return url.startsWith("http://") || url.startsWith("https://")
    }
}
