package com.videodownloader.app.utils

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import com.videodownloader.app.model.DownloadItem
import com.videodownloader.app.model.DownloadStatus
import com.videodownloader.app.model.VideoFormat
import com.videodownloader.app.model.VideoInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

class VideoDownloadManager(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.SECONDS) // No timeout for large files
        .followRedirects(true)
        .addInterceptor { chain ->
            val request = chain.request().newBuilder()
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36")
                .header("Referer", chain.request().url.host)
                .build()
            chain.proceed(request)
        }
        .build()

    private val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

    fun downloadWithSystemManager(
        videoInfo: VideoInfo,
        format: VideoFormat,
        onSuccess: (Long) -> Unit,
        onError: (String) -> Unit
    ) {
        try {
            val fileName = buildFileName(videoInfo, format)
            val subDir = when {
                format.isAudioOnly -> "VideoDownloader/Audio"
                else -> "VideoDownloader/Videos"
            }

            val request = DownloadManager.Request(Uri.parse(format.url)).apply {
                setTitle(videoInfo.title)
                setDescription("جارٍ التحميل من ${videoInfo.platform.displayName}")
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "$subDir/$fileName")
                addRequestHeader("User-Agent", "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36")
                addRequestHeader("Accept", "*/*")
                setMimeType(if (format.isAudioOnly) "audio/mpeg" else "video/mp4")
                setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI or DownloadManager.Request.NETWORK_MOBILE)
            }

            val downloadId = downloadManager.enqueue(request)
            onSuccess(downloadId)
        } catch (e: Exception) {
            onError(e.message ?: "خطأ في بدء التحميل")
        }
    }

    suspend fun downloadWithProgress(
        videoInfo: VideoInfo,
        format: VideoFormat,
        onProgress: (Int) -> Unit,
        onComplete: (String) -> Unit,
        onError: (String) -> Unit
    ) = withContext(Dispatchers.IO) {
        try {
            val fileName = buildFileName(videoInfo, format)
            val downloadDir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                if (format.isAudioOnly) "VideoDownloader/Audio" else "VideoDownloader/Videos"
            )
            downloadDir.mkdirs()
            val outputFile = File(downloadDir, fileName)

            val request = Request.Builder()
                .url(format.url)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36")
                .header("Referer", videoInfo.url)
                .build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                onError("خطأ في الاتصال: ${response.code}")
                return@withContext
            }

            val body = response.body ?: run {
                onError("لم يتم استلام البيانات")
                return@withContext
            }

            val totalBytes = body.contentLength()
            var downloadedBytes = 0L

            FileOutputStream(outputFile).use { output ->
                body.byteStream().use { input ->
                    val buffer = ByteArray(8192)
                    var bytesRead: Int
                    while (input.read(buffer).also { bytesRead = it } != -1) {
                        output.write(buffer, 0, bytesRead)
                        downloadedBytes += bytesRead
                        if (totalBytes > 0) {
                            val progress = ((downloadedBytes * 100) / totalBytes).toInt()
                            withContext(Dispatchers.Main) { onProgress(progress) }
                        }
                    }
                }
            }

            withContext(Dispatchers.Main) { onComplete(outputFile.absolutePath) }
        } catch (e: Exception) {
            withContext(Dispatchers.Main) { onError(e.message ?: "خطأ أثناء التحميل") }
        }
    }

    private fun buildFileName(videoInfo: VideoInfo, format: VideoFormat): String {
        val platformName = videoInfo.platform.displayName.replace("/", "-")
        val title = videoInfo.title
            .replace(Regex("[\\\\/:*?\"<>|]"), "_")
            .take(50)
            .trim()
        val quality = format.quality
        val ext = format.extension
        val timestamp = System.currentTimeMillis()
        return "${platformName}_${title}_${quality}_${timestamp}.${ext}"
    }

    fun getDownloadProgress(downloadId: Long): Pair<Int, DownloadStatus> {
        val query = DownloadManager.Query().setFilterById(downloadId)
        val cursor = downloadManager.query(query)

        return if (cursor.moveToFirst()) {
            val bytesDownloaded = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
            val bytesTotal = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
            val status = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
            cursor.close()

            val progress = if (bytesTotal > 0) ((bytesDownloaded * 100) / bytesTotal).toInt() else 0
            val downloadStatus = when (status) {
                DownloadManager.STATUS_RUNNING -> DownloadStatus.DOWNLOADING
                DownloadManager.STATUS_SUCCESSFUL -> DownloadStatus.COMPLETED
                DownloadManager.STATUS_FAILED -> DownloadStatus.FAILED
                DownloadManager.STATUS_PAUSED -> DownloadStatus.DOWNLOADING
                else -> DownloadStatus.PENDING
            }
            Pair(progress, downloadStatus)
        } else {
            cursor.close()
            Pair(0, DownloadStatus.PENDING)
        }
    }
}
