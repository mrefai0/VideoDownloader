package com.videodownloader.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.videodownloader.app.model.DownloadItem
import com.videodownloader.app.model.DownloadStatus
import com.videodownloader.app.model.VideoFormat
import com.videodownloader.app.model.VideoInfo
import com.videodownloader.app.utils.VideoDownloadManager
import com.videodownloader.app.utils.VideoExtractor
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class UiState {
    object Idle : UiState()
    object Loading : UiState()
    data class VideoReady(val videoInfo: VideoInfo) : UiState()
    data class Error(val message: String) : UiState()
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val extractor = VideoExtractor()
    private val downloadManager = VideoDownloadManager(application)

    private val _uiState = MutableStateFlow<UiState>(UiState.Idle)
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    private val _downloads = MutableStateFlow<List<DownloadItem>>(emptyList())
    val downloads: StateFlow<List<DownloadItem>> = _downloads.asStateFlow()

    private val _urlText = MutableStateFlow("")
    val urlText: StateFlow<String> = _urlText.asStateFlow()

    fun onUrlChanged(url: String) {
        _urlText.value = url
        if (_uiState.value is UiState.Error) {
            _uiState.value = UiState.Idle
        }
    }

    fun analyzeUrl(url: String = _urlText.value) {
        if (url.isBlank()) {
            _uiState.value = UiState.Error("الرجاء إدخال رابط الفيديو")
            return
        }

        if (!extractor.isValidUrl(url)) {
            _uiState.value = UiState.Error("الرابط غير صالح. يجب أن يبدأ بـ http:// أو https://")
            return
        }

        viewModelScope.launch {
            _uiState.value = UiState.Loading
            val result = extractor.extractVideoInfo(url)
            result.fold(
                onSuccess = { videoInfo ->
                    _uiState.value = UiState.VideoReady(videoInfo)
                },
                onFailure = { error ->
                    _uiState.value = UiState.Error(error.message ?: "فشل في تحليل الرابط")
                }
            )
        }
    }

    fun startDownload(videoInfo: VideoInfo, format: VideoFormat) {
        val downloadItem = DownloadItem(
            videoInfo = videoInfo,
            format = format,
            status = DownloadStatus.DOWNLOADING,
            progress = 0
        )

        _downloads.value = _downloads.value + downloadItem

        downloadManager.downloadWithSystemManager(
            videoInfo = videoInfo,
            format = format,
            onSuccess = { downloadId ->
                updateDownloadStatus(downloadItem.id, DownloadStatus.DOWNLOADING, 0)
                // Poll for progress
                pollDownloadProgress(downloadItem.id, downloadId)
            },
            onError = { error ->
                updateDownloadStatus(downloadItem.id, DownloadStatus.FAILED, 0, error)
            }
        )

        // Reset UI after starting download
        _uiState.value = UiState.Idle
        _urlText.value = ""
    }

    private fun pollDownloadProgress(itemId: String, systemDownloadId: Long) {
        viewModelScope.launch {
            var isRunning = true
            while (isRunning) {
                kotlinx.coroutines.delay(500)
                val (progress, status) = downloadManager.getDownloadProgress(systemDownloadId)
                updateDownloadStatus(itemId, status, progress)
                if (status == DownloadStatus.COMPLETED || status == DownloadStatus.FAILED) {
                    isRunning = false
                }
            }
        }
    }

    private fun updateDownloadStatus(
        itemId: String,
        status: DownloadStatus,
        progress: Int,
        errorMessage: String? = null
    ) {
        _downloads.value = _downloads.value.map { item ->
            if (item.id == itemId) {
                item.copy(status = status, progress = progress, errorMessage = errorMessage)
            } else item
        }
    }

    fun clearDownload(itemId: String) {
        _downloads.value = _downloads.value.filter { it.id != itemId }
    }

    fun clearAll() {
        _uiState.value = UiState.Idle
        _urlText.value = ""
    }

    fun pasteUrl(url: String) {
        _urlText.value = url
        analyzeUrl(url)
    }
}
