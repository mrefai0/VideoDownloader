package com.videodownloader.app.model

import java.io.Serializable

data class VideoInfo(
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String,
    val url: String,
    val thumbnailUrl: String? = null,
    val duration: String? = null,
    val platform: Platform,
    val formats: List<VideoFormat> = emptyList(),
    val directUrl: String? = null
) : Serializable

data class VideoFormat(
    val label: String,       // e.g. "1080p HD"
    val quality: String,     // e.g. "1080"
    val url: String,
    val extension: String = "mp4",
    val fileSize: String? = null,
    val isAudioOnly: Boolean = false
) : Serializable

enum class Platform(val displayName: String, val emoji: String, val color: Long) {
    YOUTUBE("YouTube", "▶", 0xFFFF0000),
    INSTAGRAM("Instagram", "📸", 0xFFE1306C),
    TIKTOK("TikTok", "🎵", 0xFF010101),
    TWITTER("Twitter/X", "𝕏", 0xFF1DA1F2),
    FACEBOOK("Facebook", "f", 0xFF1877F2),
    VIMEO("Vimeo", "V", 0xFF1AB7EA),
    DAILYMOTION("Dailymotion", "▷", 0xFF0066DC),
    REDDIT("Reddit", "👾", 0xFFFF4500),
    UNKNOWN("رابط عام", "🌐", 0xFF6200EE);

    companion object {
        fun fromUrl(url: String): Platform {
            return when {
                url.contains("youtube.com") || url.contains("youtu.be") -> YOUTUBE
                url.contains("instagram.com") -> INSTAGRAM
                url.contains("tiktok.com") -> TIKTOK
                url.contains("twitter.com") || url.contains("x.com") -> TWITTER
                url.contains("facebook.com") || url.contains("fb.watch") -> FACEBOOK
                url.contains("vimeo.com") -> VIMEO
                url.contains("dailymotion.com") -> DAILYMOTION
                url.contains("reddit.com") || url.contains("redd.it") -> REDDIT
                else -> UNKNOWN
            }
        }
    }
}

data class DownloadItem(
    val id: String = java.util.UUID.randomUUID().toString(),
    val videoInfo: VideoInfo,
    val format: VideoFormat,
    val status: DownloadStatus = DownloadStatus.PENDING,
    val progress: Int = 0,
    val filePath: String? = null,
    val errorMessage: String? = null,
    val startTime: Long = System.currentTimeMillis()
)

enum class DownloadStatus {
    PENDING, DOWNLOADING, COMPLETED, FAILED, CANCELLED
}
