-keepattributes *Annotation*
-keepclassmembers class ** {
    @com.google.gson.annotations.SerializedName <fields>;
}
-keep class com.videodownloader.app.model.** { *; }
-dontwarn okhttp3.**
-dontwarn okio.**
