# 📱 محمّل الفيديو - Video Downloader

تطبيق أندرويد احترافي لتحميل الفيديوهات من مواقع التواصل الاجتماعي.

---

## 🌟 المميزات

- **8 منصات مدعومة**: YouTube، TikTok، Instagram، Twitter/X، Facebook، Vimeo، Reddit، Dailymotion
- **واجهة عربية** بالكامل مع دعم RTL
- **خيارات جودة متعددة**: 4K، 1080p، 720p، 480p، 360p
- **تحميل الصوت فقط** بصيغة MP3
- **إزالة العلامة المائية** من TikTok
- **مشاركة الروابط** مباشرة من أي تطبيق
- **تحميل في الخلفية** مع إشعارات التقدم
- **متوافق مع الوضع الليلي** تلقائيًا

---

## 📋 المتطلبات

| المتطلب | الحد الأدنى |
|---------|------------|
| Android Studio | Hedgehog 2023.1+ |
| Android SDK | API 24 (Android 7.0) |
| Kotlin | 1.9.10 |
| Java | 17 |

---

## 🚀 تثبيت وتشغيل المشروع

### الخطوة 1: فتح المشروع
```bash
# افتح Android Studio واختر "Open an Existing Project"
# ثم اختر مجلد VideoDownloader
```

### الخطوة 2: مزامنة Gradle
```
File → Sync Project with Gradle Files
```

### الخطوة 3: تشغيل التطبيق
```
Run → Run 'app' (Shift+F10)
```

---

## 📁 هيكل المشروع

```
VideoDownloader/
├── app/src/main/
│   ├── java/com/videodownloader/app/
│   │   ├── model/
│   │   │   └── VideoModel.kt          # نماذج البيانات
│   │   ├── utils/
│   │   │   ├── VideoExtractor.kt      # استخراج معلومات الفيديو
│   │   │   └── VideoDownloadManager.kt # إدارة التحميل
│   │   ├── viewmodel/
│   │   │   └── MainViewModel.kt       # منطق الواجهة
│   │   ├── repository/
│   │   │   └── DownloadService.kt     # خدمة التحميل الخلفي
│   │   └── ui/
│   │       ├── MainActivity.kt        # النشاط الرئيسي
│   │       ├── MainScreen.kt          # واجهة Jetpack Compose
│   │       └── theme/
│   │           └── Theme.kt           # ثيم التطبيق
│   ├── AndroidManifest.xml
│   └── res/
│       └── values/
│           ├── strings.xml
│           ├── colors.xml
│           └── themes.xml
└── build.gradle
```

---

## 🔧 كيفية الاستخدام

### طريقة 1: نسخ الرابط يدوياً
1. انسخ رابط الفيديو من أي منصة
2. افتح التطبيق
3. اضغط زر **"لصق"** أو الصق الرابط يدوياً
4. اضغط **"تحليل الرابط"**
5. اختر الجودة المطلوبة واضغط **"تحميل"**

### طريقة 2: المشاركة المباشرة
1. افتح أي تطبيق (YouTube، TikTok، إلخ)
2. اضغط زر المشاركة على الفيديو
3. اختر **"محمّل الفيديو"** من قائمة التطبيقات
4. سيفتح التطبيق تلقائياً ويبدأ التحليل

---

## 🌐 المنصات والـ APIs المستخدمة

| المنصة | API المستخدم |
|--------|-------------|
| YouTube | YouTube oEmbed API + Cobalt.tools |
| TikTok | TikWM API (مجاني بدون مفتاح) |
| Instagram | Instagram oEmbed API |
| Twitter/X | Direct extraction |
| Facebook | Direct extraction |
| Vimeo/Dailymotion | oEmbed APIs |

---

## ⚙️ الصلاحيات المطلوبة

```xml
INTERNET                  - للتحميل من الإنترنت
WRITE_EXTERNAL_STORAGE    - لحفظ الملفات (Android ≤ 9)
POST_NOTIFICATIONS        - لإشعارات التحميل (Android 13+)
FOREGROUND_SERVICE        - للتحميل في الخلفية
```

---

## 📦 مكتبات مستخدمة

| المكتبة | الاستخدام |
|---------|-----------|
| Jetpack Compose | واجهة المستخدم |
| OkHttp 4.12 | طلبات HTTP |
| Coil 2.5 | تحميل الصور |
| Coroutines | العمليات غير المتزامنة |
| WorkManager | التحميل في الخلفية |
| Material3 | تصميم Material You |

---

## 🔮 تطوير مستقبلي

- [ ] دعم YouTube Shorts
- [ ] قاعدة بيانات لتاريخ التحميلات
- [ ] مشغل فيديو مدمج
- [ ] تحديد مجلد الحفظ
- [ ] دعم قوائم التشغيل
- [ ] وضع التحميل الدفعي

---

## ⚠️ ملاحظة قانونية

هذا التطبيق للاستخدام الشخصي فقط. يُرجى احترام حقوق الملكية الفكرية وشروط خدمة المنصات.

---

## 📄 الترخيص

MIT License - استخدام حر للأغراض الشخصية والتعليمية.
